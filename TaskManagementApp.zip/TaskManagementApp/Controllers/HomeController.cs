using Microsoft.AspNetCore.Mvc;

namespace TaskManagementApp.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}