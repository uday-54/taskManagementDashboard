﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TaskManagementApp.Data;
using TaskManagementApp.Models;
using TaskManagementApp.Models.ViewModels;
using System.Linq;

namespace TaskManagementApp.Controllers
{
    [Authorize]
    public class TasksController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public TasksController(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        public async System.Threading.Tasks.Task<IActionResult> Index(Models.TaskStatus? status, Priority? priority, string sortOrder)
        {
            var userId = _userManager.GetUserId(User);
            var query = _context.Tasks.Where(t => t.UserId == userId);

            // Filtering
            if (status.HasValue)
            {
                query = query.Where(t => t.Status == status.Value);
            }

            if (priority.HasValue)
            {
                query = query.Where(t => t.Priority == priority.Value);
            }

            // Sorting
            query = sortOrder == "date_desc"
                ? query.OrderByDescending(t => t.DueDate)
                : query.OrderBy(t => t.DueDate);

            var tasks = await query.ToListAsync();

            ViewBag.CurrentStatus = status;
            ViewBag.CurrentPriority = priority;
            ViewBag.CurrentSort = sortOrder;

            return View(tasks);
        }

        public async System.Threading.Tasks.Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var userId = _userManager.GetUserId(User);
            var task = await _context.Tasks
                .FirstOrDefaultAsync(m => m.TaskId == id && m.UserId == userId);

            if (task == null)
            {
                return NotFound();
            }

            return View(task);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async System.Threading.Tasks.Task<IActionResult> Create(TaskViewModel model)
        {
            if (ModelState.IsValid)
            {
                var task = new TaskItem
                {
                    Title = model.Title,
                    Description = model.Description,
                    Priority = model.Priority,
                    DueDate = model.DueDate,
                    Status = Models.TaskStatus.Pending,
                    CreatedAt = DateTime.Now,
                    UserId = _userManager.GetUserId(User)
                };

                _context.Add(task);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(model);
        }

        public async System.Threading.Tasks.Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var userId = _userManager.GetUserId(User);
            var task = await _context.Tasks
                .FirstOrDefaultAsync(t => t.TaskId == id && t.UserId == userId);

            if (task == null)
            {
                return NotFound();
            }

            var model = new TaskViewModel
            {
                TaskId = task.TaskId,
                Title = task.Title,
                Description = task.Description,
                Priority = task.Priority,
                DueDate = task.DueDate,
                Status = task.Status
            };

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async System.Threading.Tasks.Task<IActionResult> Edit(int id, TaskViewModel model)
        {
            if (id != model.TaskId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    var userId = _userManager.GetUserId(User);
                    var task = await _context.Tasks
                        .FirstOrDefaultAsync(t => t.TaskId == id && t.UserId == userId);

                    if (task == null)
                    {
                        return NotFound();
                    }

                    task.Title = model.Title;
                    task.Description = model.Description;
                    task.Priority = model.Priority;
                    task.DueDate = model.DueDate;
                    task.Status = model.Status;

                    _context.Update(task);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TaskExists(model.TaskId))
                    {
                        return NotFound();
                    }
                    throw;
                }
                return RedirectToAction(nameof(Index));
            }
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async System.Threading.Tasks.Task<IActionResult> MarkComplete(int id)
        {
            var userId = _userManager.GetUserId(User);
            var task = await _context.Tasks
                .FirstOrDefaultAsync(t => t.TaskId == id && t.UserId == userId);

            if (task == null)
            {
                return NotFound();
            }

            task.Status = Models.TaskStatus.Completed;
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }

        public async System.Threading.Tasks.Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var userId = _userManager.GetUserId(User);
            var task = await _context.Tasks
                .FirstOrDefaultAsync(m => m.TaskId == id && m.UserId == userId);

            if (task == null)
            {
                return NotFound();
            }

            return View(task);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async System.Threading.Tasks.Task<IActionResult> DeleteConfirmed(int id)
        {
            var userId = _userManager.GetUserId(User);
            var task = await _context.Tasks
                .FirstOrDefaultAsync(t => t.TaskId == id && t.UserId == userId);

            if (task != null)
            {
                _context.Tasks.Remove(task);
                await _context.SaveChangesAsync();
            }

            return RedirectToAction(nameof(Index));
        }

        private bool TaskExists(int id)
        {
            return _context.Tasks.Any(e => e.TaskId == id);
        }
    }
}