﻿using System.ComponentModel.DataAnnotations;

namespace TaskManagementApp.Models.ViewModels
{
    public class TaskViewModel
    {
        public int TaskId { get; set; }

        [Required]
        [StringLength(200)]
        public string Title { get; set; }

        [StringLength(1000)]
        public string Description { get; set; }

        [Required]
        public Priority Priority { get; set; }

        [Required]
        [DataType(DataType.Date)]
        public DateTime DueDate { get; set; }

        public TaskStatus Status { get; set; }
    }
}